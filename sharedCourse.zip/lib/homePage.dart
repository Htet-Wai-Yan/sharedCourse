import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Map<String, dynamic>> units = [];
  List<Map<String, dynamic>> completeLesson = [];
  @override
  void initState() {
    super.initState();
    fetchUnitCard();
    fetchLesson();
  }

  //collect all units value
  fetchUnitCard() {
    Map<String, dynamic> unit1 = {
      "cover": "data.png",
      "title": "Unit#1",
      "subTitle": "Setting Up Flutter",
    };

    Map<String, dynamic> unit2 = {
      "cover": "online.png",
      "title": "Unit#2",
      "subTitle": "Dart Basic",
    };

    Map<String, dynamic> unit3 = {
      "cover": "social.png",
      "title": "Unit#3",
      "subTitle": "Stateless & Stateful",
    };

    Map<String, dynamic> unit4 = {
      "cover": "teamwork.png",
      "title": "Unit#4",
      "subTitle": "Scrollable View",
    };

    units.addAll([unit1, unit2, unit3, unit4]);
  }

  fetchLesson() {
    Map<String, dynamic> lesson1 = {
      "title": "1.1 Installation on Windows",
      "description": "After finish learning - click \'Done\' button",
      "resource": "Video here",
    };
    Map<String, dynamic> lesson2 = {
      "title": "1.2 Installation on Mac",
      "description": "After finish learning - click \'Done\' button",
      "resource": "Video here",
    };
    Map<String, dynamic> lesson3 = {
      "title": "1.3 Flutter Command Practise",
      "description": "After finish learning - click \'Done\' button",
      "resource": "Video here",
    };
    Map<String, dynamic> lesson4 = {
      "title": "1.4 Understanding File Structure",
      "description": "After finish learning - click \'Done\' button",
      "resource": "Video here",
    };

    completeLesson.addAll([lesson1, lesson2, lesson3, lesson4]);
  }

  @override
  Widget build(BuildContext context) {
    List<Widget> unitArray = [];
    for (var courses in units) {
      // var unitCard = createUnitCard(courses);
      unitArray.add(createUnitCard(courses));
    }
    List<Widget> lessonArray = [];
    for (var lesson in completeLesson) {
      lessonArray.add(createLessons(lesson));
    }
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.blue[900],
        body: SingleChildScrollView(
          child: Column(
            // mainAxisAlignment: MainAxisAlignment.start,
            children: [
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 0, vertical: 10),
                  //HorizontalScroll
                  child: Row(
                    children: unitArray,
                  ),
                ),
              ),
              Column(
                children: lessonArray,
              ),
            ],
          ),
        ),
      ),
    );
  }

  //add image and text through Map Kay:Value
  Widget createUnitCard(Map<String, dynamic> courses) {
    return Stack(
      children: [
        Container(
          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 0),
          height: 100,
          width: 250,
          // color: Colors.white,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(5),
            boxShadow: [
              BoxShadow(
                color: Colors.black45,
                //spreadRadius: 4,
                //blurRadius: 4,
                offset: Offset(10, 10), // changes position of shadow
              ),
            ],
          ),
          child: Row(
            children: [
              Expanded(
                flex: 1,
                child: Container(
                  child: Image.asset(
                    'images/' + courses["cover"],
                  ),
                ),
              ),
              Expanded(
                flex: 2,
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        courses["title"],
                        style: TextStyle(
                          color: Colors.blue,
                          letterSpacing: 2,
                          fontSize: 20,
                        ),
                      ),
                      Text(courses["subTitle"]),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        Positioned(
          bottom: 5,
          right: 15,
          child: Icon(
            Icons.done_all_rounded,
            color: Colors.blue,
          ),
        ),
      ],
    );
  }

  //Collect all course detail
  Widget createLessons(Map<String, dynamic> lesson) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10, horizontal: 0),
      padding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
      width: 340,
      // height: 325,
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            lesson['title'],
            style: TextStyle(
              fontSize: 20,
              color: Colors.blue[800],
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            lesson['description'],
          ),
          SizedBox(
            height: 10,
          ),
          Container(
            width: 320,
            height: 200,
            color: Colors.lightGreen,
            alignment: Alignment.center,
            child: Text(
              lesson['resource'],
            ),
          ),
          SizedBox(
            height: 5,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              FlatButton(
                child: Text("Done"),
                textColor: Colors.white,
                color: Colors.blue,
                onPressed: () {},
              ),
            ],
          ),
        ],
      ),
    );
  }
}
